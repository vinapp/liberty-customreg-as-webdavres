package custuserregistrywebdav;

import java.rmi.RemoteException;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Properties;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;
import org.osgi.service.cm.ConfigurationException;
import org.osgi.service.cm.ManagedService;

import com.ibm.websphere.security.CustomRegistryException;
import com.ibm.websphere.security.UserRegistry;

/**
 * The activator class controls the plug-in life cycle
 */
public class Activator extends FileRegistrySample implements BundleActivator, ManagedService {
	private ServiceRegistration<ManagedService> configRef = null;
    private ServiceRegistration<UserRegistry> curRef = null;
    private String usersFileAttr = "usersFile";
    private String groupsFileAttr = "groupsFile";
    private String usersFile = "";
    private String groupsFile = "";
    private String CFG_PID = "customUserRegistry";

    public Activator() throws RemoteException {
    	super();
    	// TODO Auto-generated constructor stub
    }
    
    @SuppressWarnings({ "rawtypes", "unchecked" })
    Hashtable getDefaults() {
        Hashtable<String, String> defaults = new Hashtable<String, String>();
        defaults.put("service.pid", this.CFG_PID);
        return defaults;
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void start(BundleContext context) throws Exception {
        this.configRef = context.registerService((Class)ManagedService.class, (Object)this, (Dictionary)this.getDefaults());
        this.curRef = context.registerService((Class)UserRegistry.class, (Object)this, (Dictionary)this.getDefaults());
    }
    
    public void stop(BundleContext context) throws Exception {
        if (this.configRef != null) {
            this.configRef.unregister();
            this.configRef = null;
        }
        if (this.curRef != null) {
            this.curRef.unregister();
            this.curRef = null;
        }
    }
    
    @Override
    public void updated(Dictionary properties) throws ConfigurationException {
        System.out.println("Updating configuration properties");
        if (properties != null) {
            this.usersFile = (String)properties.get(this.usersFileAttr);
            System.out.println("UsersFile: " + this.usersFile);
            this.groupsFile = (String)properties.get(this.groupsFileAttr);
            System.out.println("GroupsFile: " + this.groupsFile);
            Properties initprops = new Properties();
            initprops.put("usersFile", this.usersFile);
            initprops.put("groupsFile", this.groupsFile);
            try {
                this.initialize(initprops);
            }
            catch (CustomRegistryException e) {
                e.printStackTrace();
            }
        }
    }
}

